





import React, { useState } from "react";


const accordionData = [
  {
    title: "What is your return policy?",
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
  },
  {
    title: "How do I track my order?",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.",
  },
  {
    title: "Can I purchase items again?",
    content: "Yes, you can reorder any product from your account section.",
  },
];

const Accordion = () => {

  const [activeIndex, setActiveIndex] = useState(null);



  return (
    <div  >
     
          { accordionData.map((val,ind)=>(

            <div className="border w-50 text-start m-auto p-3" key={val.title}> 

                 <div>
                      <span className="span" onClick={()=>{setActiveIndex(ind)}}>{val.title} <i className="fa-solid fa-angle-down"></i> </span>
                       <br/>
                       <p  className={'p-3'} style={{display: activeIndex ==ind ? "block" : "none"}}>
                        {val.content}
                       </p>
                 </div>

            </div>






          ))}

        
    </div>
  );
};

export default Accordion;
