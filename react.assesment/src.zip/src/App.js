import logo from './logo.svg';
import './App.css';
import Accordion from './Task';
import '../node_modules/bootstrap/dist/css/bootstrap.css'

function App() {
  return (
    <div className="App">
     <Accordion/>
    </div>
  );
}

export default App;
