
import React from "react";
import "./App.css";
import A1 from "./a1.js";
import A2 from "./A2";
import A3 from "./A3";
import A4 from "./A4";
import A5 from "./A5.js";
import UserForm from "./A5.js";
import Hook from "./hook.js";
import UseEffecthook from "./hook2.js";




function App() {
  return (
    <div className="App">
      
     <h1>react assignments</h1>
       <A1/>
       <A2/>
       <A3/>
       <A4/>
       <A5/>
       
        <Hook/>
        <UseEffecthook/>
    
    </div>
  );
}

export default App;
