
import React, { useState } from 'react'

function Hook() {

      const [Count,setcounter]=useState(0)
  return (
    <div>

        
     <button  onClick={() => setcounter(Count- 1)}>-</button>
    <h1>{Count}</h1>
   <button onClick={() => setcounter(Count+ 1)}>+</button>
    </div>
  )
}

export default Hook
