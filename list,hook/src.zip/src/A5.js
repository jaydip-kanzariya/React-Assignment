




import React, { useState } from 'react';

function A5() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [submittedData, setSubmittedData] = useState(null); 

  let handleData = (e) => {
    e.preventDefault();
    setSubmittedData({ name, email, pass });
  };

  return (
    <div>
      <form onSubmit={handleData}>
        <div>
          <label>Name</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
        </div>

        <div>
          <label>Email</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>

        <div>
          <label>Password</label>
          <input type="password" value={pass} onChange={(e) => setPass(e.target.value)} />
        </div>

        <div>
          <input type="submit" value="Submit" />
        </div>
      </form>

      {/* Show submitted data */}
      {submittedData && (
        <div>
          <h3>Submitted Data:</h3>
          <p><strong>Name:</strong> {submittedData.name}</p>
          <p><strong>Email:</strong> {submittedData.email}</p>
          <p><strong>Password:</strong> {submittedData.pass}</p>
        </div>
      )}
    </div>
  );
}

export default A5;
