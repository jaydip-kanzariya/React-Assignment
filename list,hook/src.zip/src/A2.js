import { useState } from "react"

function A2()
{
   const [age,setage]=useState('0')

    return(
        <>
           <h3>Enter your age:</h3>
           <input
        type="number"
        value={age}
        onChange={(e) => setage(e.target.value)}
        />

   <button onClick={ ()=>{age>18? alert('You are eligible to vote'): alert("You are not eligible to vote.")}}>check</button>

        </>
    )
}

export default A2