

import React from 'react'

function A3() {
   

   const fruits =["Apple", "Banana", "Cherry", "Date", "Grapes"]

  return (
    <div>
        <h1>fruits list</h1>

<ul>
           {
            fruits.map((v)=>(
               <li>{v}</li>

            ))
        }
      

</ul>
        
    </div>
  )
}

export default A3
