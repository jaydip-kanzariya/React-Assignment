

import React, { useState } from 'react'

function A1() {


  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleAuth = () => {
    setIsLoggedIn(!isLoggedIn);
  };

  return (
    <div>
      
        
        <div>
      <button onClick={handleAuth}>
        {isLoggedIn ? "Logout" : "Login"}
      </button>
      <p>{isLoggedIn ? "You are logged in!" : "You are logged out!"}</p>

    </div>

    


    </div>
  )
}

export default A1
