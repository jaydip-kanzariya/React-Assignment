
import React from 'react'

function A4() {


    const users = [
        { id: 1, name: "xyz1" },
        { id: 2, name: "xyz2" },
        { id: 3, name: "xyz3" },
        { id: 4, name: "xyz4" },
        { id: 5, name: "xyz5" }
      ];
  return (
    <div>
        <h3>user list</h3>
        <ul>
            {
                users.map((v)=>(
                    <li key={v.id}>{v.name}</li>
                ))
            }
        </ul>
    


    </div>
  )
}

export default A4
