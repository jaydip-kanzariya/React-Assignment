
import React, { useEffect, useState } from 'react'

function UseEffecthook() {


  const [data,setData] = useState([])

     
    useEffect(()=>{
      fetch('https://jsonplaceholder.typicode.com/users')
      .then((res)=>{return res.json()})
      .then((data)=>{
           console.log(data)
           setData(data)
      })
  },[])

  return (
    <div>
      
      <h1>UseEffect Hook, API Data</h1>
             {data.map((v)=>(
                <li style={{padding:"10px 0"}}>{v.id} {" "} {v.name}</li>
             ))}


    </div>
  )
}

export default  UseEffecthook;
