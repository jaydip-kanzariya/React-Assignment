


function Test2() {
    const x = "React";
  
    return (
      <div>
        <h1>Welcome to JSX</h1>
        <p>{x}</p>
      </div>
    );
  }
  
  export default Test2;