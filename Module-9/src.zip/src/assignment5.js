import './App.css';

 function Test5({id,name,dis})
 {

    return(
        <>
         
         <div className="row">
           < div className='col'>
           <h1>{id}</h1>
            <h3>{name}</h3>
            <p>
                 {dis}
            </p>

         </div>
         </div>
        
        
        </>
    )
 }

 export default Test5;