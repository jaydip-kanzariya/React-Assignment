import React from "react";

class Test4 extends React.Component
{
    
     render()
     {
        return(

            <>
            
            <h1>welcome  </h1>
            
            </>
        )

     }
}

export default Test4;