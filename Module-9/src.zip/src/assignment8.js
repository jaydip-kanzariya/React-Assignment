

   function Test8()
   {
         
     function write()
     {
        var inp= document.querySelector("input")
          var h1=document.getElementById("h1")
         h1.innerHTML=inp.value
     }

      return(
        <>
          <br/>
           
           <br/>
              <input type="text"  placeholder=" enter text" onKeyUp={write} />
               
               <h1 id="h1">

               </h1>
        </>
      )
   }

   export default Test8;