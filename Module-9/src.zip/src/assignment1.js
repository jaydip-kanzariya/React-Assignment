

function Test() {
    return (
      <div>
        <h1>Hello, React!</h1>
      </div>
    );
  }

  export default Test;