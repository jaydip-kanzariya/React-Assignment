

function Test7()
{
  
     function ch()
     {
        document.getElementById("b1").innerHTML="Clicked"

     }

     return(
        <>
           <br/>
           <br/>
           <button id="b1" onClick={ch}>Not Clicked</button>

        </>
     )
}

export default Test7;