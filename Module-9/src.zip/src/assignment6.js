import React from "react"

 class Test6 extends React.Component
 {
      state= {num:1}

   change = ()=>{
    this.setState({num:this.state.num +1})
   }

     
     render()
     {
        return(
            <>

            <h1>{this.state.num}</h1>
            <button onClick={this.change}> +</button>

            </>
        )
     }

 }

 export default Test6;