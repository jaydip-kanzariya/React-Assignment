


function Test3({ name }) {
    return <h1>Hello, {name}!</h1>;
  }
  
  export default Test3;