import logo from './logo.svg';
import './App.css';
import Test from './assignment1'
import Test2 from './assignment2';
import Test3 from './assignment3';
import Test4 from './assignment4';
import Test5 from './assignment5';
import Test6 from './assignment6';
import Test7 from './assignment7';
import Test8 from './assignment8';


function App() {
  return (
    <div className="App">
      
       
     <Test/>
      <Test2/>
      <Test3 name="jaydip" />
      <Test4/>
      <Test5  id={1} name={"jaydip"} dis={"product discription text"} />
     <Test6/>
     <Test7/>
     <Test8/>
     

    </div>
  );
}

export default App;
