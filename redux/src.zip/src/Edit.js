

import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useParams } from 'react-router-dom'
import { editdata } from './reducer'

function Edit() {

    // const {id}=useParams
 
    const [name, setName] = useState("")
    const [price, setPrice] = useState("")
   const prd = useSelector(state => state.data)
    const {id} = useParams()
    const disptach = useDispatch()
    console.log(id)
//   const prd =  useSelector(state => state.data)

 
   

    useEffect(() => {
           fetch('http://localhost:5000/product/'+id)
               .then((res) => {return res.json()})
               .then((data)=> {
                 setName(data.name)
                 setPrice(data.price)
                 console.log(data)
               })
       },[])
 
           

  

const handleedit = (e)=>{
 e.preventDefault()
 disptach(editdata({id:id,name,price}))
 window.location.reload()
 
}


    return (
        <>
        <div>

            <Link className='btn btn-primary' to='/'>home</Link>


            <form className='text-start' onSubmit={handleedit} >
                <div className="mb-3">
                    <label className="form-label">name</label>
                    <input type="text" value={name} onChange={(e) => {setName(e.target.value) }}  className="form-control" id="exampleInputEmail1" />

                </div>
                <div className="mb-3">
                    <label className="form-label">price</label>
                    <input type="text" value={price} onChange={(e) => {setPrice(e.target.value) }} className="form-control" id="exampleInputPassword1" />
                </div>

                <button type="submit" className="btn btn-primary">update</button>
            </form> 

        </div>
        </>
    )
}

export default Edit;
