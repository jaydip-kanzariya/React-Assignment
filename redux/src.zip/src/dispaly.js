

import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { adddata, deldata } from './reducer'
import { Link, useParams } from 'react-router-dom'

function Dispaly() {

    const [products] = useSelector(state => state.prodata)
    const dispach = useDispatch()


    const {id}=useParams




    console.log(products)

    useEffect(() => {

        fetch('http://localhost:5000/product')
            .then((res) => { return res.json() })
            .then((dt) => {

                // console.log(dt)
                dispach(adddata(dt))
            })
    }, [])



       
   const handleDelete = (id)=>{
       dispach(deldata({id}))

       window.location.reload()
   }




    return (
        <div>

            <h1>data</h1>
            <Link className='btn btn-primary' to='add'>add </Link>
            <table className='table'>

                <thead className=' table-dark'>
                    <tr>
                        <th>id</th>
                        <th>name</th>
                        <th>price</th>
                        <th>action</th>

                    </tr>
                </thead>

                <tbody>
                    { products && products.map((v) => {
                        return (
                            <tr key={v.id}>
                                <td>{v.id}</td>
                                <td>{v.name}</td>
                                <td>{v.price}</td>
                                <td>
                                    <Link to={`/edit/${v.id}`} className='btn btn-success'>EDIT</Link>
                                    
                                    <button className='btn btn-success mx-2' onClick={()=>{handleDelete(v.id)}}>delete</button>
                                </td>
                            </tr>

                        )


                    })}

                </tbody>

            </table>



        </div>
    )
}

export default Dispaly;
