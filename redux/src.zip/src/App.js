// import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import Dispaly from './dispaly';
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import Add from './Add';
import Edit from './Edit';

function App() {
  return (
    <div className="App">
       
         <h1>redux json</h1>
         <BrowserRouter>

 <Routes>
      <Route path='/' element={<Dispaly/>}></Route>
      <Route path='/add' element={<Add/>}></Route>
      <Route path='/edit/:id' element={<Edit/>}></Route>
      {/* <Route path='/add' element={<Addstudentdata/>}></Route>
      <Route path='/edit/:id' element={<Edit/>}></Route>
      <Route path='/view/:id' element={<View/>}></Route> */}

     </Routes>
 
 </BrowserRouter>
    </div>
  );
}

export default App;
