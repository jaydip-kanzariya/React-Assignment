

import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { putData } from './reducer'
import { useDispatch } from 'react-redux'

function Add() {
    const [name,setName] = useState("")
    const [price,setPrice] = useState("")
   
    const dispatch = useDispatch()

    const handleAdd = (e)=>{
         e.preventDefault()

         dispatch(putData({name,price}))
         window.location.reload()
    }
  return (
    <div>
         <Link className='btn btn-primary' to='/'>home</Link>
     <form className='text-start' onSubmit={handleAdd}>
  <div className="mb-3">
    <label  className="form-label">name</label>
    <input value={name} onChange={(e)=>{setName(e.target.value)}} type="text" className="form-control" id="exampleInputEmail1" />
    
  </div>
  <div className="mb-3">
    <label className="form-label">price</label>
    <input value={price} onChange={(e)=>{setPrice(e.target.value)}} type="text" className="form-control" id="exampleInputPassword1" />
  </div>
 
  <button type="submit" className="btn btn-primary">Submit</button>
</form>


    </div>
  )
}

export default Add
