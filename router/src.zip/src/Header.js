

import React from 'react'
import { Link } from 'react-router-dom'

function Header() {
  return (
    <div >
         <nav className="navbar navbar-expand-lg navbar-light shadow">

         <ul className="nav navbar-nav d-flex justify-content-between mx-lg-auto">
          <li className="nav-item ">
            <Link className="nav-link text-success" to="/">Home</Link>
          </li>
          
          <li className="nav-item ">
            <Link className="nav-link text-success" to="about">About</Link>
          </li>
          <li className="nav-item ">
            <Link className="nav-link text-success" to="contact">contact</Link>
          </li>
        </ul>
        </nav>

    </div>
  )
}

export default Header
