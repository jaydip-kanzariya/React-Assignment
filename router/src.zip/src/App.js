import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Route,  } from "react-router-dom"

import Home from './home';
import Header from './Header';
import About from './About';
import "../node_modules/bootstrap/dist/css/bootstrap.css"
import Contact from './Contact';

function App() {
  return (
    <div className="App"> 
   
    
           
<BrowserRouter>
      
      <Header/>
  
       
   <Routes>
     <Route path='/' element={<Home/>}>
    
     </Route>
     <Route path='/about' element={<About/>}> </Route>
     <Route path='/contact' element={<Contact/>}> </Route>
    

   </Routes>
</BrowserRouter>

     
    </div>
  );
}

export default App;
